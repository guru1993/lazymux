# app (Lazymux-App)
This is the source code of Lazymux app  
You can build/rebuild Lazymux by using this source code

## How to Build
1. First, you need to install DroidScript Premium on your phone and DroidScript ApkBuilder Plugin  
2. Place this folder (app) onto /sdcard/DroidScript and don't forget to change the name of this folder (app) to Lazymux  
3. Now open DroidScript, you'll gonna see an icon of Lazymux app  
4. Press and Hold icon of Lazymux, then dialog box will popup and choose Build APK  
5. Done!!  

Happy Build <3  


LICENSE
___
MIT